#include "COMPort.h"

#define COM_TimeStopBit(_SB_) ((float)(((_SB_) == QSerialPort::OneAndHalfStop)? (1.5f) : (_SB_)))
#define COM_TimeParityBit(_PB_) ((float)(((_PB_) == QSerialPort::NoParity)? (0.0f) : (1.0f)))

COMPort::COMPort(QObject *parent) :
    QSerialPort(parent)
{
    //Register declared data type (for signal-slot queued connections)
    qRegisterMetaType<COMPort::Param_t>("COMPort::Param_t");
}

COMPort::~COMPort()
{
}

//Static method to scan currently available serial port and return a list with their names and parameters
QList<QStringList> COMPort::scanPorts()
{
    QList<QStringList> ports;
    QString description;
    QString manufacturer;
    QString serialNumber;
    QString systemLocation;
    const auto infos = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &info : infos) {
        QStringList list;
        description = info.description();
        manufacturer = info.manufacturer();
        serialNumber = info.serialNumber();
        systemLocation = info.systemLocation();
        list << info.portName()
             << (!description.isEmpty() ? description : "N/A")
             << (!manufacturer.isEmpty() ? manufacturer : "N/A")
             << (!serialNumber.isEmpty() ? serialNumber : "N/A")
             << (!systemLocation.isEmpty() ? systemLocation : "N/A")
             << (info.vendorIdentifier() ? QString::number(info.vendorIdentifier(), 16) : "N/A")
             << (info.productIdentifier() ? QString::number(info.productIdentifier(), 16) : "N/A");
        ports.append(list);
    }
    return ports;
}

//Method to perform a blocking write operation, monitoring disconnection and/or timeout events
bool COMPort::blockingWrite(const QByteArray &txBuff, const uint &tBreak1Byte)
{
    uint32_t tOut = 0;
    //Start write
    this->write(txBuff);
    this->flush();
    this->waitForBytesWritten(20);
    //Acquire number of bytes still to be written
    qint64 nBytesToWrite=this->bytesToWrite();
    while(nBytesToWrite) {
        //Keep flushing out
        this->flush();
        bool isComOk=this->waitForBytesWritten(20);
        //Check if number of bytes to be written has changed
        if(nBytesToWrite>this->bytesToWrite()) {
            //bytes have been written: all good
            nBytesToWrite=this->bytesToWrite();
            //reset timeout
            tOut=0;
        } else {
            //bytes have not been written: check if an error has been issued
            if(isComOk) {
                //WARNING: bytes have not been written BUT no error from com port has been issued
                //THIS SCENARIO HAS BEEN TESTED TO BE THE "LOST COM" SCENARIO
                //so, transmission has failed
                return false;
            }
        }
        //Regardless if bytes have been written or no, check if com port has issued some error
        if(!isComOk){
            //Read error and put it in a variable (for debug)
            QSerialPort::SerialPortError err=this->error();
            switch (err) {
                case QSerialPort::TimeoutError: {
                        //Timeout error (not critical), possibly due to com bufferization
                        tOut+=20;
                        break;
                }
                case QSerialPort::NoError:{
                        //No error: do nothing
                        break;
                }
                default:{
                        //Com error detected: communication has failed. Abort
                        return false;
                }
            }
            //Clear com errors for next operation
            this->clearError();
        }
        //Check if timeout value is more than the lengt of the buffer times the provided tBreak1Byte
        if(tOut>txBuff.length()*tBreak1Byte){
            //Timeout reached: communication failed
            return false;
        }
    }
    //Communication succesfully completed: all data have been written
    return true;
}

//Open/re-open serial port with last connection parameters
bool COMPort::openPort()
{
    //Close port
    this->COMPort::closePort();

    //Serial port is now certainly close: check port name
    if (this->QSerialPort::portName().isEmpty()) {
        //No port name currently available: can't open port
        return false;
    }

    //Attempt to open serial port and return result of operation
    if(this->QSerialPort::open(QIODevice::ReadWrite)) {
        //Update transmit/receive time [ms] of 1 byte (based on current connection parameters)
        m_timeout1Byte = ( 1000.0 * (((float)(this->QSerialPort::dataBits())) + COM_TimeStopBit(this->QSerialPort::stopBits()) + COM_TimeParityBit(this->QSerialPort::parity())) ) / ((float)this->QSerialPort::baudRate());
        return true;
    }
    return false;
}

//Open/re-open serial port with new connection parameters
bool COMPort::handlePort(const COMPort::Param_t &par)
{
    //Close port
    this->COMPort::closePort();

    //Serial port is now certainly close: check port name
    if ((par.name.isEmpty()) || (par.name == "Disconnect")) {
        //No port name provided or disconnection requested: abort
        this->QSerialPort::setPortName("");
        return false;
    }

    //A new port name is provided: apply it to serial port
    this->QSerialPort::setPortName(par.name);
    //Attempt to apply new connection parameters to serial port
    if (!this->COMPort::initPort(par)) {
        //Application of current connection parameters failed: can't open port
        return false;
    }

    //Attempt to open serial port and return result of operation
    if(this->QSerialPort::open(QIODevice::ReadWrite)) {
        //Update transmit/receive time [ms] of 1 byte (based on current connection parameters)
        m_timeout1Byte = ( 1000.0 * (((float)(this->QSerialPort::dataBits())) + COM_TimeStopBit(this->QSerialPort::stopBits()) + COM_TimeParityBit(this->QSerialPort::parity())) ) / ((float)this->QSerialPort::baudRate());
        return true;
    }
    return false;
}

void COMPort::closePort()
{
    //Reset m_timeout1Byte value
    m_timeout1Byte = 1.0;

    //If serial port is open, close it
    while (this->QSerialPort::isOpen()) {
        this->QSerialPort::clear();
        this->QSerialPort::clearError();
        this->QSerialPort::close();
    }
}

//Attempt to apply connection parameters (except com name) to serial port
bool COMPort::initPort(const COMPort::Param_t &par)
{
    //Init return value
    bool out = true;
    //Apply new connection parameters
    out &= this->QSerialPort::setBaudRate(par.baudRate);
    out &= this->QSerialPort::setDataBits(par.dataBits);
    out &= this->QSerialPort::setStopBits(par.stopBits);
    out &= this->QSerialPort::setParity(par.parity);
    out &= this->QSerialPort::setFlowControl(par.flowControl);
    //If at least one of the setting went bad, return value will be false
    return out;
}

