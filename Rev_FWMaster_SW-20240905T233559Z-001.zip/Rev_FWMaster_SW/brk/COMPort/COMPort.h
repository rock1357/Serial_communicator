#ifndef COMPORT_H
#define COMPORT_H

#include <QObject>
#include <QSerialPort>
#include <QSerialPortInfo>

class COMPort : public QSerialPort
{
    Q_OBJECT

public:
    //Enumerator to extend Baud Rates from QSerialPort
    enum Baud {
        B1200 = QSerialPort::Baud1200,
        B2400 = QSerialPort::Baud2400,
        B4800 = QSerialPort::Baud4800,
        B9600 = QSerialPort::Baud9600,
        B19200 = QSerialPort::Baud19200,
        B38400 = QSerialPort::Baud38400,
        B57600 = QSerialPort::Baud57600,
        B115200 = QSerialPort::Baud115200,
        B230400 = 230400,
        B460800 = 460800,
        B576000 = 576000,
        B921600 = 921600,
    };
    Q_ENUM(Baud)

    //Structure to handle COMPort parameters
    typedef struct Param {
        QString name = "";
        qint32 baudRate = QSerialPort::Baud9600;
        QSerialPort::DataBits dataBits = QSerialPort::Data8;
        QSerialPort::Parity parity = QSerialPort::NoParity;
        QSerialPort::StopBits stopBits = QSerialPort::OneStop;
        QSerialPort::FlowControl flowControl = QSerialPort::NoFlowControl;
        Param(const QString &n):name(n){};
        Param(const QSerialPort::BaudRate &b):baudRate(b){};
        Param(const qint32 &b):baudRate(b){};
        Param(const QString &n, const Param &p):name(n),baudRate(p.baudRate),dataBits(p.dataBits),parity(p.parity),stopBits(p.stopBits),flowControl(p.flowControl){};
        Param(const COMPort *p):name(p->portName()),baudRate(p->baudRate()),dataBits(p->dataBits()),parity(p->parity()),stopBits(p->stopBits()),flowControl(p->flowControl()){};        
    }Param_t;

    COMPort(QObject *parent=nullptr);
    ~COMPort();

    //Return current connection parameters
    COMPort::Param_t param(){return COMPort::Param_t(this);};

    //Return current time [ms] needed to transmit/receive 1 byte (based on current connection parameters)
    float timeout1Byte(){return m_timeout1Byte;};

    //Static method to scan currently available serial port and return a list with their names and parameters
    static QList<QStringList> scanPorts();

    //Method to perform a blocking write operation, monitoring disconnection and/or timeout events
    bool blockingWrite(const QByteArray &txBuff, const uint &tBreak1Byte);

public slots:
    //Open/re-open serial port with current connection parameters
    bool openPort();

    //Update connection parameters then open the serial port
    bool handlePort(const Param_t &par);

    //Check if serial port is open, if so closes it
    void closePort();

private:
    //Attempt to apply connection parameters (except com name) to serial port
    bool initPort(const Param_t &par);

    //Property holding current time [ms] needed to transmit/receive 1 byte (based on current connection parameters)
    float m_timeout1Byte = 1.0;
};
#endif // COMPORT_H
