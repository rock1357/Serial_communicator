#include "ConnectionWidget.h"
#include "ui_ConnectionWidget.h"

#include <QSettings>
#include <About.h>

ConnectionWidget::ConnectionWidget(const QString &name, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ConnectionWidget)
{
    ui->setupUi(this);
    //Set custom object name
    this->setObjectName(name);
    //Apply custom name to UI element's toolTip
    ui->lbLed->setToolTip(name);
    ui->cbLink->setToolTip(name);
    //Show initial icon
    ui->lbLed->setPixmap(QPixmap(":/LedGreenOff.png"));

    //Create reLink timer
    m_par.reLinkTim = new QTimer();
    m_par.reLinkTim->setTimerType(Qt::CoarseTimer);
    m_par.reLinkTim->setSingleShot(true);
    m_par.reLinkTim->setInterval(0);
    m_par.reLinkTim->callOnTimeout(this,[&](){
        //Periodically emit setLink signal with current connection parameter
        emit setLink(m_par.port);
    });

    //Use default .ini file to store/load ConnectionWidget parameters
    QSettings SET INIT_FILE;
    SET.beginGroup("PAR_COM_"+this->objectName());
    QStringList keys=SET.allKeys();
    if(keys.isEmpty()) {
        SET.setValue("NAME",m_par.port.name);
        SET.setValue("BAUD",QString::number(m_par.port.baudRate));
        SET.setValue("BITS",QString::number(m_par.port.dataBits));
        SET.setValue("PARITY",QString::number(m_par.port.parity));
        SET.setValue("STOP_BIT",QString::number(m_par.port.stopBits));
        SET.setValue("FLOW_CONTROL",QString::number(m_par.port.flowControl));
    } else {
        m_par.port.name=SET.value("NAME").toString();
        m_par.port.baudRate=SET.value("BAUD").toUInt();
        m_par.port.dataBits=QSerialPort::DataBits(SET.value("BITS").toUInt());
        m_par.port.parity=QSerialPort::Parity(SET.value("PARITY").toUInt());
        m_par.port.stopBits=QSerialPort::StopBits(SET.value("STOP_BIT").toUInt());
        m_par.port.flowControl=QSerialPort::FlowControl(SET.value("FLOW_CONTROL").toUInt());

    }
    SET.endGroup();

    //Update list of available COM port
    updatePortList();
    //Try using old port name
    setPortName(m_par.port.name);

    //update port list every time Link is clicked
    connect(ui->cbLink,&CustomComboBox::showPopupSignal,this,&ConnectionWidget::updatePortList);
    //connect to new port every time the user actually choose a port
    connect(ui->cbLink,&QComboBox::textActivated,this,[&](const QString &text) {
        //change port name to the one actually selected from widget
        setPortName(text);
        //emit setLink signal with current connection parameters
        emit setLink(m_par.port);
    });

}

ConnectionWidget::~ConnectionWidget()
{
    delete ui;
}

//Set new connection parameters (except port name), then emit setLink singal
void ConnectionWidget::startLink(const COMPort::Param_t &par)
{
    //Assign new connection parameters, except port name
    setPortParam(par);
    //Emit setLink signal with current connection parameters
    emit setLink(m_par.port);
}

//Set value of reLink timer timeout (a value of 0 disable timer)
void ConnectionWidget::setReLinkTimeout(const uint &tOut)
{
    //Check if tOut value is different from current one
    if(tOut == m_par.reLinkTim->interval()) {
        //timeout not changed do nothing (avoid useless start/stop)

        return;
    }

    //Stop reLink timer
    m_par.reLinkTim->stop();
    //Change timeout
    m_par.reLinkTim->setInterval(tOut);
    //Check current connection status
    if((!m_par.linkStat) && (m_par.port.name != "Disconnect")) {
        //Connection is off: start reLink if tOut is != 0
        if(tOut) {
            m_par.reLinkTim->start();
        }
    }
}

//Slot dedicated to the reaction on a linkFeedback signal emitted from backend
void ConnectionWidget::onLinkFeedback(const bool &linkStat)
{
    if(linkStat) {
        //Save last functioning parameters in default .ini file
        QSettings SET INIT_FILE;
        SET.beginGroup("PAR_COM_"+this->objectName());
            SET.setValue("NAME",m_par.port.name);
            SET.setValue("BAUD",QString::number(m_par.port.baudRate));
            SET.setValue("BITS",QString::number(m_par.port.dataBits));
            SET.setValue("PARITY",QString::number(m_par.port.parity));
            SET.setValue("STOP_BIT",QString::number(m_par.port.stopBits));
            SET.setValue("FLOW_CONTROL",QString::number(m_par.port.flowControl));
        SET.endGroup();
        //Update icon
        onSetLed(":/LedYellowOn.png");
    } else {
        //Update icon
        onSetLed(":/LedGreenOff.png");
    }
    //If link status has changed, update status variable & emit signal
    if(m_par.linkStat!=linkStat) {

        m_par.linkStat=linkStat;
        emit linkStatChanged(m_par.linkStat);

        //Check connection status
        if(m_par.linkStat) {
            //Connection is up: disable reLink timer
            m_par.reLinkTim->stop();
            //Update port list
            updatePortList();
        } else {
            //Check if reLink timer is enabled
            if((m_par.reLinkTim->interval() > 0) && (m_par.port.name != "Disconnect")) {
                //reLink timer enabled: activate it
                m_par.reLinkTim->start();
            }
        }
    } else {
        //if link stat ha not changed
        if(!linkStat) {
            //if port has signaled that it's disconnected
            //Check if reLink timer is enabled
            if((m_par.reLinkTim->interval() > 0) && (m_par.port.name != "Disconnect")) {
                //reLink timer enabled: activate it
                m_par.reLinkTim->start();
            }
        }
    }
}

//Slot dedicated to the reaction on a setLed signal emitted from backend
void ConnectionWidget::onSetLed(const QString &ledName)
{
    ui->lbLed->setPixmap(QPixmap(ledName));
    emit ledChanged(ledName);
}

//Attempt to assign a specific port name (fails if chosen name does not currently exist)
void ConnectionWidget::setPortName(QString name)
{
    for(int ndx=0; ndx<ui->cbLink->count(); ndx++) {
        if(ui->cbLink->itemText(ndx) == name) {
            //Port name found in current port list
            ui->cbLink->setCurrentIndex(ndx);
            m_par.port.name = name;
            //If selected port is Disconnect, set an empty port name
            if(m_par.port.name == "Disconnect"){
                m_par.reLinkTim->stop();
            }
            return;
        }
    }
    //Port name not found in current port list
    //(for example, due to reconnection after program shutdown, using old port name)
    m_par.port.name = "Disconnect";
}

//Scan alla avaible ports and update widget list
void ConnectionWidget::updatePortList()
{
    //Remove all items from combo box
    ui->cbLink->clear();
    //Add default (Disconnect) item
    ui->cbLink->addItem("Disconnect");
    //Scan and get all available port names
    QList<QStringList> portsInfos = COMPort::scanPorts();
    //Cycle over every port found
    for(int i=0; i<portsInfos.length(); i++) {
        //Set port name as combo box item name
        ui->cbLink->addItem(portsInfos.at(i).at(0), portsInfos.at(i));
        //Set port infos as combo box item tooltip
        ui->cbLink->setItemData(i+1, portsInfos.at(i).at(1), Qt::ToolTipRole);
    }
    for(int ndx=0; ndx<ui->cbLink->count(); ndx++) {
        if(ui->cbLink->itemText(ndx) == m_par.port.name) {
            //Port name found in current port list
            ui->cbLink->setCurrentIndex(ndx);
            return;
        }
    }
}
