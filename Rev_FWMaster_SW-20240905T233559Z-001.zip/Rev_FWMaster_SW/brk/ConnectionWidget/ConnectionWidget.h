//CONNECTIONWIDGET_H---------------------------------------------------------------------
#ifndef CONNECTIONWIDGET_H
#define CONNECTIONWIDGET_H

#include <QWidget>
#include <COMPort.h>
#include <QTimer>

namespace Ui {
class ConnectionWidget;
}

class ConnectionWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ConnectionWidget(const QString &name, QWidget *parent = nullptr);
    ~ConnectionWidget(void);

    //Return status of connection
    bool linkStat(void){return m_par.linkStat;};

    //Return name of current port
    QString portName(void){return m_par.port.name;};

    //Return current connection parameters
    COMPort::Param_t portParam(void){return m_par.port;};

    //Return current value of reLink timer timeout (a value of 0 means timer disabled)
    uint reLinkTimeout(void) {return m_par.reLinkTim->interval();};

signals:
    //Signal dedicated to trigger port opening from backend
    void setLink(const COMPort::Param_t &par);
    //Signal dedicated to notify a change in the connection status to front end
    void linkStatChanged(bool linkStat);
    //Signal dedicated to notify a change of the led pixmap
    void ledChanged(const QString &ledName);
public slots:
    //Set new connection parameters (except port name), then emit setLink singal
    void startLink(const COMPort::Param_t &par);

    //Set new connection parameters (except port name)
    void setPortParam(const COMPort::Param_t &par){
        //Assign new connection parameters, except port name
        m_par.port = COMPort::Param_t(m_par.port.name,par);        
    };


    //Set value of reLink timer timeout (a value of 0 disable timer)
    void setReLinkTimeout(const uint &tOut);

    //Slot dedicated to the reaction on a linkFeedback signal emitted from backend
    void onLinkFeedback(const bool &linkStat);

    //Slot dedicated to the reaction on a setLed signal emitted from backend
    void onSetLed(const QString &ledName);

private:
    Ui::ConnectionWidget *ui;

    //Structure to handle ConnectionWidget properties
    typedef struct Param {
        COMPort::Param_t port = COMPort::Param_t("Disconnect");    //Property holding current connection parameters
        bool linkStat = false;    //Property holding current status of the connection
        QTimer* reLinkTim = nullptr;  //Timer dedicated to automatic reconnection (disabled if timeout is set to 0)        
    } Param_t;

    Param_t m_par;
    //Attempt to assign a specific port name (fails if chosen name does not currently exist)
    void setPortName(QString name="Disconnect");

private slots:
    //Scan alla avaible ports and update widget list
    void updatePortList();
};
#endif // CONNECTIONWIDGET_H
