#ifndef BRKDEF_H_IN
#define BRKDEF_H_IN

#define SOFT_NAME "PRDisplay"
#define SOFT_VERSION "0.1.0"
#define CB_VERSION "2.2.1"
#define SOFT_BIN_TYPE "64"
#define QT_FULL_VERSION "6.5.2"
#define GCC_FULL_VERSION "11.2.0"

#endif // BRKDEF_H_IN
