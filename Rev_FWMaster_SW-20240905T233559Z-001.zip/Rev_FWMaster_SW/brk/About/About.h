/*COMMON BRICKS VERSION NUMBER
2.2.1
COMMON BRICKS VERSION NUMBER*/

#ifndef ABOUT_H
#define ABOUT_H

#include <QDialog>
#include <QDir>
#include <BrkDef.h>

#define INIT_FILE (QDir::currentPath()+"/data/init.ini",QSettings::IniFormat)

namespace Ui {
class About;
}

class About : public QDialog
{
    Q_OBJECT

public:
    //Structure to handle About information
    typedef struct info {
        QString swName=SOFT_NAME;
        QString swVers=SOFT_VERSION;
        QString cbVers=CB_VERSION;
        QString qtVers=QT_FULL_VERSION;
        QString qtKit=QString("MinGW %1, %2 bit").arg(GCC_FULL_VERSION,SOFT_BIN_TYPE);
        QString companyName="GRAF Industries S.p.A.";
        QString companyAdrs="Via G. Galilei, 32/36\n41015 Nonantola (MO), Italy";
        QString companyWeb="https://www.grafindustries.com";        
    } info_t;

    explicit About(QWidget *parent);
    ~About();

    static const About::info_t& info(){return m_info;};

    void addAbout(QString title, QString file, QStringList args);

public slots:
    void openIni(void);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    Ui::About *ui;        

    static About::info_t m_info;
};



//CUSTOMCOMBOBOX_H-----------------------------------------------------------------------
#ifndef CUSTOMCOMBOBOX_H
#define CUSTOMCOMBOBOX_H

#include <QComboBox>

class CustomComboBox : public QComboBox
{
    Q_OBJECT

public:
    CustomComboBox (QWidget *parent = nullptr) : QComboBox(parent){};
    ~CustomComboBox(){};
    void showPopup() override {
        emit showPopupSignal();
        QComboBox::showPopup();
    };

signals:
    void showPopupSignal();
};

#endif // CUSTOMCOMBOBOX_H
#endif // ABOUT_H
