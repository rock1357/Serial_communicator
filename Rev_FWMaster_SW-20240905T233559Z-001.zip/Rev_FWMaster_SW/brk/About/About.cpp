#include "About.h"
#include "ui_About.h"

#include <QFile>
#include <QDesktopServices>

About::About(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::About)
{
    ui->setupUi(this);

    //Register declared data type (for signal-slot queued connections)
    qRegisterMetaType<info_t>("info_t");

    Qt::WindowFlags flags=Qt::Dialog;
    flags |= Qt::WindowTitleHint;
    flags |= Qt::WindowCloseButtonHint;
//    flags |= Qt::MSWindowsFixedSizeDialogHint;
    setWindowFlags(flags);
    setWindowTitle(tr("About ")+info().swName);

    ui->lbProgInfo->setText(info().swName+" ver. "+info().swVers);
    ui->lbCompilerInfo->setText(tr("Based on Qt ")+info().qtVers+" - "+tr("Built with ")+info().qtKit);
    ui->lbCompanyInfo->setText(info().companyName+" - "+info().companyAdrs);
    QString linkFormat="<a href=\"%1/\">%1</a>";
    ui->lbCompanyWeb->setText(linkFormat.arg(info().companyWeb));

    ui->lbProgImg->setPixmap(QPixmap(":/ProgImg.png"));
    ui->lbLogoInventa->setPixmap(QPixmap(":/LogoInventa.png"));
    ui->lbLogoIndustries->setPixmap(QPixmap(":/LogoIndustries.png"));

    ui->twAbout->setTabText(0,tr("About ")+info().swName);
    QFile aboutEULAFile(":/aboutEULA.txt");
    aboutEULAFile.open(QFile::ReadOnly | QFile::Text);
    ui->tbAboutEULA->setHtml(QString(aboutEULAFile.readAll()).arg(info().swName,info().companyName));
    aboutEULAFile.close();

    addAbout(tr("About Qt"),":/aboutQt.txt",QStringList({info().qtVers}));
}

About::~About()
{
    delete ui;
}

void About::paintEvent(QPaintEvent *event)
{
    //This way the UI stays at the minimum size, but it's still capable of resizing
    //to allow proper display of widgets
    this->resize(this->sizeHint());
}

void About::addAbout(QString title, QString file, QStringList args)
{
    //Create new tab
    QWidget* tab = new QWidget();
    //Set up new tab main layout
    QHBoxLayout* hl= new QHBoxLayout(tab);
    //Set up new tab main text browser
    QTextBrowser* tb = new QTextBrowser(tab);
    //Add main text browser to main layout
    hl->addWidget(tb);

    //Add new tab to tab widget
    ui->twAbout->addTab(tab, title);

    //Open file containing informations that needs to be showed in a specific about tab
    QFile aboutFile(file);
    aboutFile.open(QFile::ReadOnly | QFile::Text);
    //If some arguments have been provided, use them inside the showed text
    tb->setTextInteractionFlags(Qt::LinksAccessibleByMouse);
    QString text(aboutFile.readAll());
    foreach (const QString& a, args) {
        text=text.arg(a);
    }
    //Close file
    aboutFile.close();

    //Add final text to main text browser & set some properties
    tb->setHtml(text);
    tb->setOpenExternalLinks(true);
    tb->setReadOnly(true);
}

void About::openIni()
{
    QDesktopServices::openUrl(QUrl(QDir::currentPath()+"/data/init.ini"));
}

About::info_t About::m_info;
